import UIKit

protocol HamburgerViewControllerDelegate {
    func hideHamburgerMenu()
}
class HamburgerViewController: UIViewController {

    var delegate : HamburgerViewControllerDelegate?
    
   
    @IBOutlet weak var profilePictureImage: UIImageView!
    
    @IBOutlet weak var mainBackgroundView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.setupHamburgerUI()
        // Do any additional setup after loading the view.
    }
    
    private func setupHamburgerUI()
    {
        self.mainBackgroundView.layer.cornerRadius = 40
        self.mainBackgroundView.clipsToBounds = true
        
        self.profilePictureImage.layer.cornerRadius = 40
        self.profilePictureImage.clipsToBounds = true
    }
    
    @IBAction func clickedOnButton(_ sender: Any) {
        self.delegate?.hideHamburgerMenu()
    }
    
    @IBAction func Contactanos(_ sender: UIButton) {
        let alerta = UIAlertController(title: "Contactanos!", message: "alu.18131215@correo.itlalaguna.edu.mx", preferredStyle: .alert)
        let accionCancelar = UIAlertAction(title: "Cancelar", style: .destructive)
        let accionAceptar = UIAlertAction(title: "Aceptar", style: .default) { _ in
            print("Correo")
        }
        
        alerta.addAction(accionCancelar)
        alerta.addAction(accionAceptar)
        
        present(alerta,animated: true)
        self.delegate?.hideHamburgerMenu()
    }
    @IBAction func Acercadebutton(_ sender: UIButton) {
        
        let alerta = UIAlertController(title: "CEAG!", message: "Empresa dedicada a mejorar estilos de vida", preferredStyle: .alert)
        let accionCancelar = UIAlertAction(title: "Cancelar", style: .destructive)
        let accionAceptar = UIAlertAction(title: "Aceptar", style: .default) { _ in
            print("Correo")
        }
        
        alerta.addAction(accionCancelar)
        alerta.addAction(accionAceptar)
        
        present(alerta,animated: true)
        self.delegate?.hideHamburgerMenu()
    }
    
}
