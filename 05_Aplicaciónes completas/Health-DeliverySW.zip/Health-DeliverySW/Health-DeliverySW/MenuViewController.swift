//
//  MenuViewController.swift
//  Health-DeliverySW
//
//  Created by Daniel Saldivar on 10/05/23.
//


import UIKit
protocol MenuViewControllerDelegate{
    func hideMenu()
}
class MenuViewController: UIViewController {

    var delegate : MenuViewControllerDelegate?
    
    @IBOutlet weak var PerfilPic: UIImageView!
    @IBOutlet weak var mainBackgroundMenu: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
    }
    
   
    @IBAction func BuPerfilBut(_ sender: UIButton) {
        self.delegate?.hideMenu()
    }
    //Cierra la ventada de accion del menu de comida y opciones

    @IBAction func ButmENU(_ sender: Any) {
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
